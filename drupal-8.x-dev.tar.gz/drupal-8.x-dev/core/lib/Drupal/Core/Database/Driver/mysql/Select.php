<?php

/**
 * @file
 * Definition of Drupal\Core\Database\Driver\mysql\Select
 */

namespace Drupal\Core\Database\Driver\mysql;

use Drupal\Core\Database\Query\Select as QuerySelect;

class Select extends QuerySelect { }
