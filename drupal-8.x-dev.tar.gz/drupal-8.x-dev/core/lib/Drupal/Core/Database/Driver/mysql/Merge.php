<?php

/**
 * @file
 * Definition of Drupal\Core\Database\Driver\mysql\Merge
 */

namespace Drupal\Core\Database\Driver\mysql;

use Drupal\Core\Database\Query\Merge as QueryMerge;

class Merge extends QueryMerge { }
